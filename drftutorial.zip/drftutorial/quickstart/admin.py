from django.contrib import admin
from quickstart.models import ToDoList

# Register your models here.

admin.site.register(ToDoList)
